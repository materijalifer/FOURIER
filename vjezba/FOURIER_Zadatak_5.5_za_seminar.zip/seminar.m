clear;
clc;

syms y(t)
y(t) = dsolve('D2y + 2*Dy + 2*y == 3*cos(6*t)', y(0) == 0, 'Dy(0) == 0');

t = 0:.01:2*pi;
plot(t, y(t))
hold all

n=16;
t = 1*(2*pi/n):2*pi/n:2*pi-(2*pi/n);
plot(t, diskret(n))
hold all

n=64;
t = 1*(2*pi/n):2*pi/n:2*pi-(2*pi/n);
plot(t, diskret(n))
hold all

n=256;
t = 1*(2*pi/n):2*pi/n:2*pi-(2*pi/n);
plot(t, diskret(n))
hold all

legend('Egzaktno rje�enje', 'n=16', 'n=64', 'n=256');
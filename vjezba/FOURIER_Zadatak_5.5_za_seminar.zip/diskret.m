function u = diskret(n)
a = 1;
b = 2;
c = 2;
h = 2*pi/n;
beta = c*h^2 + b*h - 2*a;
gama = a - b*h;
w = exp(2*pi*1i/n);
f = @(t) 3*cos(6*t);
k = 1:(n-1);
ftrans = fft(f(2*pi*k/n));
utrans = zeros(1,(n-1));
for m = 1:(n-1)
   utrans(m) = ((h^2).*ftrans(m))./(a*(w.^m) + beta + gama*(conj(w).^m));
end
u = ifft(utrans);